=== SW Slider Widget ===
Contributors: flytheme.com
Demo link: http://demo.flytheme.com/#sw-smooth-slideshow
Tags: blogs, carousel, categories, category, content, CSS, featured, flash, gallery, home, image, jquery, page, picture, plugin, Post, posts, responsive, shortcode, sidebar, simple, site, slider, slideshow, Style, thumbnail, widget, wpmu, wordpress, cms, free.
Requires at least: 3.1
Tested up to: 3.5
Stable tag: trunk

Smooth slideshow to show your posts with images, title and description.

== Description ==

This is a slideshow with many effects and smooth.It support multi widgets that mean you can show more than one slideshow on one page.

Featuring some interesting posts now becomes easier and cooler with SW Smooth Slideshow. With an navigation by images that can be placed above or below main slide, this plugin helps both aesthetics and navigation of Website. Going through all featured posts by images will offer your Website opportunity to get more traffic and conversion.

=> Features slideshow widget <=

=* Data config *=

+ Select categories from category list (Posts has Featured image)
+ Support select orderby
+ Support select order
+ Could Set number of posts
+ Could set length of description
+ Support one theme

=* Effect configs *=

+ Animation : Center or sides
+ Config 'auto play': Yes/No
+ Config 'Slideshow interval': Time for each change image
+ Config 'Speed of effect'
+ Select easing type for images ( 12 types )
+ Easing types: easeInBounce, easeOutBounce, easeInOutBack,  easeOutBack, easeInOutElastic, easeOutElastic, easeInElastic, easeInOutCirc, easeOutCirc, swing, easeInQuad, easeInOutQuint.

<a href="http://www.flytheme.com" target="_blank">Plugin Home Page</a> | <a href="http://demo.flytheme.com/#sw-smooth-slideshow" target="_blank">Demo</a> | <a href="http://www.flytheme.com/wordpress/plugins/item/438-sw-smooth-slideshow-free-responsive-wordpress-plugin" target="_blank">Plugin Documentation</a>

== Installation ==

First download this widget
Then Upload to install it in you admin layout => Active widget.
Go to Widget manage page and publish it.

== Changelog ==

== Upgrade Notice ==

== Screenshots ==

1. Demo 1: Thumb images on the bottom
2. Demo 1: Thumb images on the top
3. Plugin's configs